package id.authlite;

import io.papermc.paper.event.player.AsyncChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.title.Title;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.File;
import java.security.SecureRandom;
import java.util.*;

public class AuthLite extends JavaPlugin implements Listener {

    // Koordinat palsu tempat pemain "ditahan" sebelum login
    private static final double FAKE_X = 0.5, FAKE_Y = 100, FAKE_Z = 0.5;
    private static final int LOGIN_TIMEOUT_SECONDS = 60;

    private final Set<UUID> authed = new HashSet<>();
    private final Map<UUID, Location> realLoc = new HashMap<>();
    private File dataFile;
    private YamlConfiguration data;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "accounts.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        Bukkit.getPluginManager().registerEvents(this, this);
        // Kalau reload saat ada pemain online, tahan semuanya lagi
        for (Player p : Bukkit.getOnlinePlayers()) lock(p);
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!authed.contains(p.getUniqueId())) unlock(p);
        }
    }

    // ---------- Lock / Unlock ----------

    private boolean isAuthed(Player p) { return authed.contains(p.getUniqueId()); }

    private void lock(Player p) {
        UUID id = p.getUniqueId();
        authed.remove(id);
        realLoc.put(id, p.getLocation().clone());

        World w = Bukkit.getWorlds().get(0);
        p.teleport(new Location(w, FAKE_X, FAKE_Y, FAKE_Z));
        p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, PotionEffect.INFINITE_DURATION, 0, false, false, false));
        p.setInvulnerable(true);

        boolean registered = data.contains("players." + p.getName().toLowerCase());
        Title.Times times = Title.Times.times(Duration.ZERO, Duration.ofSeconds(LOGIN_TIMEOUT_SECONDS), Duration.ZERO);
        if (registered) {
            p.showTitle(Title.title(Component.text("Silakan Login", NamedTextColor.YELLOW),
                    Component.text("/login <password>", NamedTextColor.WHITE), times));
            p.sendMessage("§eSilakan login: §f/login <password>");
        } else {
            p.showTitle(Title.title(Component.text("Silakan Daftar", NamedTextColor.YELLOW),
                    Component.text("/register <password> <password>", NamedTextColor.WHITE), times));
            p.sendMessage("§eSilakan daftar: §f/register <password> <password>");
        }

        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline() && !isAuthed(p)) p.kick(net.kyori.adventure.text.Component.text("Waktu login habis."));
        }, LOGIN_TIMEOUT_SECONDS * 20L);
    }

    private void unlock(Player p) {
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.removePotionEffect(PotionEffectType.DARKNESS);
        p.setInvulnerable(false);
        p.clearTitle();
        Location back = realLoc.remove(p.getUniqueId());
        if (back != null) p.teleport(back);
    }

    // ---------- Password ----------

    private String hash(String pw, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pw.toCharArray(), salt, 120_000, 256);
        byte[] h = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(h);
    }

    private String makeEntry(String pw) throws Exception {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt) + ":" + hash(pw, salt);
    }

    private boolean isOwner(String name) {
        for (String o : getConfig().getStringList("owner-names")) if (o.equalsIgnoreCase(name)) return true;
        return false;
    }

    private final Map<String, Boolean> premiumCache = new ConcurrentHashMap<>();

    /** true = nama ada di Mojang, false = tidak, null = gagal cek */
    private Boolean isPremium(String name) {
        Boolean c = premiumCache.get(name.toLowerCase());
        if (c != null) return c;
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.mojang.com/users/profiles/minecraft/" + name))
                    .timeout(Duration.ofSeconds(5)).GET().build();
            int code = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.discarding()).statusCode();
            if (code == 200) { premiumCache.put(name.toLowerCase(), true); return true; }
            if (code == 404 || code == 204) { premiumCache.put(name.toLowerCase(), false); return false; }
        } catch (Exception ignored) { }
        return null;
    }

    // Tolak nama premium milik orang lain (dicek sebelum pemain masuk server)
    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        String name = e.getName();
        if (!getConfig().getBoolean("block-premium-names", true)) return;
        if (isOwner(name) || data.contains("players." + name.toLowerCase())) return;
        if (!name.matches("[A-Za-z0-9_]{3,16}")) return;
        if (Boolean.TRUE.equals(isPremium(name))) {
            e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    Component.text("Nama ini milik akun premium. Pakai nama lain."));
        }
    }

    private void save() {
        try { data.save(dataFile); } catch (Exception e) { getLogger().severe("Gagal simpan: " + e.getMessage()); }
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("authadmin")) {
            if (s instanceof Player) { s.sendMessage("§cHanya bisa dari console."); return true; }
            if (args.length != 3 || !args[0].equalsIgnoreCase("set")) { s.sendMessage("Pakai: authadmin set <nama> <password>"); return true; }
            try {
                data.set("players." + args[1].toLowerCase(), makeEntry(args[2]));
                save();
                s.sendMessage("Password " + args[1] + " diset.");
            } catch (Exception ex) { ex.printStackTrace(); }
            return true;
        }
        if (!(s instanceof Player p)) return true;
        String key = "players." + p.getName().toLowerCase();
        try {
            if (cmd.getName().equalsIgnoreCase("register")) {
                if (isAuthed(p) || data.contains(key)) { p.sendMessage("§cKamu sudah terdaftar. Pakai /login."); return true; }
                if (isOwner(p.getName())) { p.sendMessage("§cAkun ini diproteksi. Password diset admin lewat console."); return true; }
                if (args.length != 2 || !args[0].equals(args[1])) { p.sendMessage("§cPakai: /register <password> <ulangi password>"); return true; }
                if (args[0].length() < 6) { p.sendMessage("§cPassword minimal 6 karakter."); return true; }
                byte[] salt = new byte[16];
                new SecureRandom().nextBytes(salt);
                data.set(key, Base64.getEncoder().encodeToString(salt) + ":" + hash(args[0], salt));
                save();
                authed.add(p.getUniqueId());
                unlock(p);
                p.sendMessage("§aBerhasil daftar!");
            } else {
                if (isAuthed(p)) { p.sendMessage("§cKamu sudah login."); return true; }
                String stored = data.getString(key);
                if (stored == null) { p.sendMessage("§cBelum terdaftar. Pakai /register."); return true; }
                if (args.length != 1) { p.sendMessage("§cPakai: /login <password>"); return true; }
                String[] parts = stored.split(":");
                byte[] salt = Base64.getDecoder().decode(parts[0]);
                if (hash(args[0], salt).equals(parts[1])) {
                    authed.add(p.getUniqueId());
                    unlock(p);
                    p.sendMessage("§aLogin berhasil!");
                } else {
                    p.sendMessage("§cPassword salah.");
                }
            }
        } catch (Exception e) {
            p.sendMessage("§cTerjadi error.");
            e.printStackTrace();
        }
        return true;
    }

    // ---------- Events ----------

    @EventHandler public void onJoin(PlayerJoinEvent e) { lock(e.getPlayer()); }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        // Balikin ke lokasi asli supaya posisi asli yang tersimpan, bukan koordinat palsu
        if (!isAuthed(p)) unlock(p);
        authed.remove(p.getUniqueId());
        realLoc.remove(p.getUniqueId());
    }

    // Blok SEMUA command selain login/register, termasuk untuk OP
    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (isAuthed(e.getPlayer())) return;
        String msg = e.getMessage().substring(1).trim().toLowerCase();
        String first = msg.split("\\s+")[0];
        if (first.contains(":")) first = first.substring(first.indexOf(':') + 1);
        if (!first.equals("login") && !first.equals("register")) {
            e.setCancelled(true);
            e.getPlayer().sendMessage("§cLogin dulu sebelum pakai command.");
        }
    }

    // Sembunyikan daftar command di tab-complete
    @EventHandler
    public void onCommandSend(PlayerCommandSendEvent e) {
        if (isAuthed(e.getPlayer())) return;
        e.getCommands().removeIf(c -> !c.equals("login") && !c.equals("register"));
    }

    @EventHandler public void onMove(PlayerMoveEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onChat(AsyncChatEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInteract(PlayerInteractEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInteractEntity(PlayerInteractEntityEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onDrop(PlayerDropItemEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onBreak(BlockBreakEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onPlace(BlockPlaceEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onSwap(PlayerSwapHandItemsEvent e) { if (!isAuthed(e.getPlayer())) e.setCancelled(true); }
    @EventHandler public void onInvOpen(InventoryOpenEvent e) {
        if (e.getPlayer() instanceof Player p && !isAuthed(p)) e.setCancelled(true);
    }
    @EventHandler public void onInvClick(InventoryClickEvent e) {
        if (e.getWhoClicked() instanceof Player p && !isAuthed(p)) e.setCancelled(true);
    }
    @EventHandler public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player p && !isAuthed(p)) e.setCancelled(true);
    }
}
